//
//  FlashLightViewController.swift
//  FlashLight
//
//  Created by Taylor Phillips on 1/30/17.
//  Copyright © 2017 Taylor Phillips. All rights reserved.
//

import UIKit

class FlashLightViewController: UIViewController {
var isOn = false
    @IBOutlet weak var FlashLightButton: UIButton!
    @IBAction func FlashLightButtonTapped(_ sender: Any) {
        
        if isOn {
           self.isOn = false
            self.view.backgroundColor = UIColor.black
            self.FlashLightButton.setTitle("ON", for: .normal)
            self.FlashLightButton.setTitleColor(UIColor.white, for: .normal)
            
        }
        else{
            self.isOn = true
            self.view.backgroundColor = UIColor.white
            self.FlashLightButton.setTitle("OFF", for: .normal)
            self.FlashLightButton.setTitleColor(UIColor.black, for: .normal)
        

            
        
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
